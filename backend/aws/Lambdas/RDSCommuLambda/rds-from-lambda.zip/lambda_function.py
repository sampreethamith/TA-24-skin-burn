import pymysql
from pymysql.cursors import Cursor

#Configuration environment values
endpoint = 'aws-rds-db.cfrwh9mf3ygt.us-east-2.rds.amazonaws.com'
username = 'admin'
pwd = 'adminadmin'
database_name = 'TEST'

#Connection string build
connection = pymysql.connect(host=endpoint, user=username, password=pwd, database=database_name) 

def print_table(cursor: Cursor, table_name: str):
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

def lambda_handler():
    cursor = connection.cursor()
    print_table(cursor, "TBL1")
    cursor.execute('INSERT INTO `TEST`.`TBL1` (`uid`, `name`, `count`) VALUES ("6", "test", "60");')
    print_table(cursor, "TBL1")